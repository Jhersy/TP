package tp.pr4.control;

import java.util.Scanner;

import tp.pr4.logic.*;

/**
 * Implementacion del jugador humano del juego complica.
 * 
 * @author Jhersy Nolasco y Roberto Barrasus
 * 
 */
public class JugadorHumanoCo implements Jugador {

	private Scanner in;

	public JugadorHumanoCo(Scanner in) {
		this.in = in;
	}

	@Override
	public Movimiento getMovimiento(Tablero tab, Ficha color) {

		String op;
		System.out.print("Introduce columna: ");
		op = in.nextLine().trim();
		int col = Integer.parseInt(op);

		return new MovimientoComplica(col, color);
	}

}
